package com.example.ejercicio3;




public class ejercicio {
    public int[] twoSum(int[] nums, int target) {

        for (int i = 0; i < numeros.length; i++) {
            int complement = target - nums[i];
            if (map.containsKey(complement)) {
                return new int[]{map.get(complement), i};
            }
            map.put(nums[i], i);
        }
        return new int[]{};

        public static void main (String[]args){
            int numeros[] = {2, 3, 7, 10, 27, 31, 35, 39, 42, 38};
            ;
            int target = 9;
            int[] result = twoSum(nums, target);
            System.out.println(Arrays.toString(result));

        }
    }
}